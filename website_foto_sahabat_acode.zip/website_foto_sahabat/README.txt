CARA PAKAI DI ACODE
1. Ekstrak folder website_foto_sahabat.
2. Buka folder tersebut di Acode.
3. Buka index.html.
4. Jalankan Preview/Browser Preview.
5. Semua foto sudah ada di folder assets.

Untuk mengganti judul/nama, edit bagian <title>, h1, dan teks di index.html.
