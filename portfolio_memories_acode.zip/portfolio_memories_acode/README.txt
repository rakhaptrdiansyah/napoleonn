PORTFOLIO MEMORIES — ACODE

1. Ekstrak ZIP.
2. Buka folder di Acode.
3. Buka index.html.
4. Jalankan Preview.

Semua foto ada di assets/.
Edit judul/nama/teks langsung di index.html.
